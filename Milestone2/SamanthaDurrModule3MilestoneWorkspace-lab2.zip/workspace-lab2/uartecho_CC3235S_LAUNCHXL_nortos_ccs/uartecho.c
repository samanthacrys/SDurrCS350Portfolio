/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uartecho.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>

/* Driver configuration */
#include "ti_drivers_config.h"


//Available states
//State Before any command is entered.
#define WAITING_FOR_FIRST_CHARACTER 0

//The letter O has been entered waiting for an N or F
#define WAITING_FOR_SECOND_CHARACTER 1

//The letters OF have been entered wait for an F or invalid letter.
#define WAITING_FOR_THIRD_CHARACTER 2

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char        input;

    //Set for the state change of the LED states.
    unsigned char state = 0;

    const char  echoPrompt[] = "Echoing characters:\r\n";

    UART_Handle uart;
    UART_Params uartParams;

    /* Call driver init functions */
    GPIO_init();
    UART_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    UART_write(uart, echoPrompt, sizeof(echoPrompt));

    //Set initial state waiting for the first character of the command.
    state = WAITING_FOR_FIRST_CHARACTER;

    /* Loop forever echoing */
    while (1) {

        UART_read(uart, &input, 1);
        UART_write(uart, &input, 1);

        //Turn the input to upper case so that only 1 type of character needs to be checked.
        input = toupper(input);

        //Receives the state and input to find out if the light needs to be turned on or off.
        //All states are waiting for the O, but the case will look for the second character or
        //third character to find out if the light is to be on or off.
        switch( state )
        {
            case WAITING_FOR_FIRST_CHARACTER:
                if ( input == 'O' )
                {
                    //Changes the state to wait for the second character..
                    state = WAITING_FOR_SECOND_CHARACTER;
                }
                break;
            case WAITING_FOR_SECOND_CHARACTER:
                if ( input == 'N' )
                {
                    //Turns the LED to on.
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                    //Returns to the waiting_for_first_character state.
                    state = WAITING_FOR_FIRST_CHARACTER;
                }
                else if ( input == 'F' )
                {
                    //Changes the state to wait for the third character or an invalid command.
                    state = WAITING_FOR_THIRD_CHARACTER;
                }
                else
                {
                    //If the command is invalid, then go and wait for the first character again.
                    state = WAITING_FOR_FIRST_CHARACTER;
                }
                break;
            case WAITING_FOR_THIRD_CHARACTER:
                if ( input == 'F' )
                {
                    //Turns the light off.
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                }
                //Changes the state to go back and wait for the first character.
                state = WAITING_FOR_FIRST_CHARACTER;
                break;
        }
    }
}
